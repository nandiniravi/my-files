import React from 'react';
import './Cards.css';
import menu from '../../assets/menu.png';
import desserts from '../../assets/apple-pie.jpg';
import drinks from '../../assets/beer.jpg';
import events from '../../assets/partyhall1.jpg';
import contact from '../../assets/contact.jpg';
import {Link} from 'react-router-dom';

const cards = () => {
    return(
      <div className="container">
         <div className="row justify-content-md-center">
           <Link to="/Menu" className="col-sm-12 col-md-9 col-lg-3 Cards" style={{backgroundImage: `url(${menu})`,backgroundSize: "cover", backgroundPosition: "center"}}><div>Menu</div></Link>
            <Link to="/Desserts" className="col-sm-12 col-md-9 col-lg-3 Cards" style={{backgroundImage: `url(${desserts})`,backgroundSize: "cover",backgroundPosition: "center"}}><div>Desserts</div></Link>
            <Link to="/Drinks" className="col-sm-12 col-md-9 col-lg-3 Cards" style={{backgroundImage: `url(${drinks})`,backgroundSize: "cover", backgroundPosition: "center"}}><div>Drinks</div></Link>
            <Link to="/Events" className="col-sm-12 col-md-9 col-lg-3 Cards" style={{backgroundImage: `url(${events})`,backgroundSize: "cover", backgroundPosition: "center"}}><div>Events</div></Link>
            <Link to="/Contact-us" className="col-sm-12 col-md-9 col-lg-3 Cards" style={{backgroundImage: `url(${contact})`,backgroundSize: "cover", backgroundPosition: "center"}}><div>Contact</div></Link>
        </div>
      </div>

      
    );
}

export default cards;
import React from 'react';
import Herobanner from '../../assets/hero-banner.jpg';
import './Contactus.css'

const contactus = () => {
    return(
        <div className="Contactus">
            <img src={Herobanner} alt="Hero Banner"/>
            <h1>Contact Us</h1>
            <p>We would love to hear from you, write to us at <a href="mailto:dineout@mail.com">dineout@mail.com</a></p>
            <p>Contact No: +91 90000 000000</p>
            <p>No. 6, Paradise Towers,<br></br>
            8th Cross street,<br></br>
            Mylapore,<br></br>
            Chennai - 600 004</p>
        </div>
    );
}

export default contactus;
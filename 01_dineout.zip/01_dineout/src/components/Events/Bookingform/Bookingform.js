import React from 'react';
import './Bookingform.css';

class Bookingform extends React.Component{
    state = {
        name: '',
        contact: '',
        email: '',
        eventName: '',
        date: '',
        ems : '',
    };

    nameHandler = (event) => {
        this.setState({name :event.target.value});
    }

    contactHandler = (event) => {
        this.setState({ contact :event.target.value});
    }

    emailHandler = (event) => {
        this.setState({email:event.target.value});
    }

    eventNameHandler = (event) => {
        this.setState({eventName:event.target.value});
    }

    dateHandler = (event) => {
        this.setState({date:event.target.value});
    }

    emsUpdateHandler = (event) => {
        this.setState({ems:event.target.value});
    }

    render(){
        // var today = new Date();
        // var year = today.getFullYear();
        // var month = today.getMonth();
        // var date = today.getDate();
        // if(date<10){
        //     date='0'+date;
        // } 
        // if(month<10){
        //     month='0'+month;
        // } 
        // var minDate = year+'-'+month+'-'+date;
    
        return(
            <div className="Bookingform">
                <h3>Booking details</h3><br></br>
                <form>
                    Name: <input type="text" placeholder="Your first name" onChange={this.nameHandler}/><br></br>
                    Mobile Number: <input type="number" placeholder="Your contact number" onChange={this.contactHandler}/><br></br>
                    Email: <input type="email" placeholder="Your email" onChange={this.emailHandler}/><br></br>
                    Celebration Event: <input type="text" placeholder="Celebration event" onChange={this.eventNameHandler}/><br></br>
                    Date of celebration: <input type="date" onChange={this.dateHandler}/><br></br>
                    Avail our Event Management Service?<br></br>
                    <select name="ems" onChange={this.emsUpdateHandler}>
                        <option value=""></option>
                        <option value="yes">Yes</option>
                        <option value="no">No</option>
                    </select><br></br><br></br>
                    {/* <input type="radio" id="yes" value="yes" onChange={this.yesHandler} style={{display: "inline-block", width: "20%"}}/><label>Yes</label>
                    <input type="radio" id="no" value="no" onChange={this.noHandler} style={{display: "inline", width: "20%"}}/><label>No</label><br></br><br></br> */}
                    <button onClick={this.props.submitForm}>Submit</button>
                    <button onClick={this.props.cancelForm}>Cancel</button>
                </form>           
            </div>
        );
    }
}

export default Bookingform;
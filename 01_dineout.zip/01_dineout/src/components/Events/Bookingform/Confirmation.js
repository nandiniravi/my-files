import  React from 'react';
import './Confirmation.css';

const confirmation = (props) => {
    return(
        <div className="Confirmation">
            <p>Thank you for choosing us to celebrate the memorable moments of your life. We have received your details, we will contact you shortly regarding the availability of the chosen party hall.</p>
            <button onClick={props.closeConfirmation}>Okay</button>
        </div>
    );
}

export default confirmation;
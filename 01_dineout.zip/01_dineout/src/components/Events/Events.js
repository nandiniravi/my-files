import React from 'react';
import './Events.css';
import partyhall1 from '../../assets/partyhall1.jpg';
import partyhall2 from '../../assets/partyhall2.jfif';
import partyhall3 from '../../assets/partyhall3.jpg';
import partyhall4 from '../../assets/partyhall4.jfif';
import partyhall5 from '../../assets/partyhall5.jfif';
import partyhall6 from '../../assets/partyhall6.jfif';
import Bookingform from './Bookingform/Bookingform';
import Confirmation from './Bookingform/Confirmation';

class Events extends React.Component{
    state = {
        eventName : '',
        guestsRange : '',
        priceRange : [],
        filterApplied : false,
        filteredArray: [],
        showForm: false,
        showConfirmation: false
    };
    myDataArray = [
        {   id: 1,
            name: "Sapphire",
            guestsRange: "Less than 200",
            price: 3000,
            priceRange: "Less than ₹ 5000",
            src: {partyhall1}
        },
        {   id: 2,
            name: "Ruby",
            guestsRange: "200-300",
            price: 4000,
            priceRange: "Less than ₹ 5000",
            src: {partyhall2}
        },
        {   id: 3,
            name: "Blue Diamond",
            guestsRange: "500-700",
            price: 6000,
            priceRange: "₹ 5000 to ₹ 7000",
            src: {partyhall3}
        },
        {   id: 4,
            name: "Emerald",
            guestsRange: "1000-1500",
            price: 8000,
            priceRange: "₹ 7000 to ₹ 9000",
            src: {partyhall4}
        },
        {   id: 5,
            name: "Kohinoor",
            guestsRange: "Greater than 1500",
            price: 10000,
            priceRange: "More than ₹ 9000",
            src: {partyhall5}
        },
        {   id: 6,
            name: "Amethyst",
            guestsRange: "500-700",
            price: 6000,
            priceRange: "₹ 5000 to ₹ 7000",
            src: {partyhall6}
        }
    ];

    updateEventName = (event) => {
        this.setState({eventName : event.target.value});
    }

    updateGuestRange = (event) => {
        this.setState({guestsRange : event.target.value});
    }

    updatePriceRange = (event) => {
        const myArray = this.state.priceRange;
        const chosenValue = event.target.value;
        if (myArray.includes(chosenValue)){
            const index = myArray.indexOf(chosenValue);
            myArray.splice(index,1);
        }
        else
            myArray.push(chosenValue);
        this.setState({priceRange : myArray});
        // console.log(myArray);
    }

    updateValues = (event) => {
        event.preventDefault();
        // console.log(this.state);

        var myFilteredArray = null;
        if((this.state.guestsRange !== '') && (this.state.priceRange.length === 0)){
            // console.log('condition 1');
            myFilteredArray = this.myDataArray.filter(each => {
                if(each.guestsRange === this.state.guestsRange){
                    return(each);
                }
            });
        }
        else if((this.state.guestsRange === '') && (this.state.priceRange.length !== 0)){
            // console.log('condition 2');
            myFilteredArray = this.myDataArray.filter(each => {
                for(let i in this.state.priceRange){
                    if (each.priceRange === this.state.priceRange[i])
                        return(each);
                }
            })
        }
        else if((this.state.guestsRange !== '') && (this.state.priceRange.length !== 0)){
            // console.log('condition 3');
            myFilteredArray = this.myDataArray.filter(each => {
                if(each.guestsRange === this.state.guestsRange){
                    for(let i in this.state.priceRange){
                        if (each.priceRange === this.state.priceRange[i])
                            return(each);
                }
            }});
        }
        else if((this.state.guestsRange === '') && (this.state.priceRange.length === 0))
            return(this.myDataArray);

    // console.log(myFilteredArray);
    this.setState({filterApplied: true, filteredArray: myFilteredArray});
    }

    clearFilterHandler = (event) =>{
        this.setState(
            {
                eventName : '',
                guestsRange : '',
                priceRange : [],
                filterApplied : false
            }
        );
    }

    showFormHandler = (event) => {
        this.setState({showForm: true});
    }

    cancelFormHandler = (event) => {
        this.setState({showForm: false});
    }

    submitFormHandler = (event) => {
        this.setState({showForm: false, showConfirmation: true});
    }

    closeConfirmationHandler = (event) => {
        this.setState({showConfirmation : false});
    }
    
    render(){
        let myArray = null;
        if(this.state.filterApplied && this.state.filteredArray.length !== 0)
            myArray = this.state.filteredArray;
        else if(this.state.filterApplied && this.state.filteredArray.length === 0)
            myArray = null;
        else
            myArray = this.myDataArray;

        var myHallsElement = null;
        if(myArray !== null){
            myHallsElement = myArray.map(each => {
                    return(
                        <div className="col-sm-12 col-md-6 col-lg-4 EventCards" key={each.id}>
                            <img src={Object.values(each.src)} alt={each.name}/>
                            <p>{each.name}<br></br>₹ {each.price}</p>
                            <button className="BooknowButton" onClick={this.showFormHandler}>Book Now</button>
                        </div>
                    );
                });
            }
        else
            myHallsElement = <p>Sorry, there are no party halls with the given criteria!</p>
        
        let formElement = null;
        if(this.state.showForm)
            formElement =  <Bookingform
                            submitForm={this.submitFormHandler}
                            cancelForm={this.cancelFormHandler}/>;
        else
            formElement = null;
            
        let confirmation = null;
        if(this.state.showConfirmation)
            confirmation = <Confirmation closeConfirmation={this.closeConfirmationHandler}/>
        return(
            <div>
                <h1 style={{backgroundColor: "#1E9DB0",fontWeight: "lighter", padding: "5px 0px 5px 0px"}}>Events</h1>
                <form className="Events">
                    Celebration Event: 
                    <input type="text" placeholder="What are you celebrating today?" onChange={this.updateEventName}/><br></br>
                    Guests Expected: 
                    <select name="guestsRange" onChange={this.updateGuestRange}>
                        <option value=""></option>
                        <option value="Less than 200">Less than 200</option>
                        <option value="200-300">200-300</option>
                        <option value="500-700">500-700</option>
                        <option value="1000-1500">1000-1500</option>
                        <option value="Greater than 1500">Greater than 1500</option>
                    </select><br></br><br></br>
                    Price Range: 
                    <div className="Checkbox">
                        <div><input type="checkbox" value="Less than ₹ 5000" onClick={this.updatePriceRange}/><label>Less than ₹ 5000</label></div>
                        <div><input type="checkbox" value="₹ 5000 to ₹ 7000" onClick={this.updatePriceRange}/><label>₹ 5000 to ₹ 7000</label></div>
                        <div><input type="checkbox" value="₹ 7000 to ₹ 9000" onClick={this.updatePriceRange}/><label>₹ 7000 to ₹ 9000</label></div>
                        <div><input type="checkbox" value="More than ₹ 9000" onClick={this.updatePriceRange}/><label>More than ₹ 9000</label></div>
                    </div><br></br>
                    <button onClick={this.updateValues}>Filter</button>
                    <button onClick={this.clearFilterHandler}>Clear Filter</button>
                </form>
                {myHallsElement}
                {formElement}
                {confirmation}
            </div>
        );
    }
}

export default Events;
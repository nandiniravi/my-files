import React from 'react';
import './Footer.css';

const footer = () => {
    return(
        <div className="Footer">
            <span><a href="https://www.facebook.com" target="_blank" rel="noopener noreferrer" className="fa fa-facebook"> </a></span>
            <span><a href="https://www.twitter.com" target="_blank" rel="noopener noreferrer" className="fa fa-twitter"> </a></span>
            <span><a href="https://www.instagram.com" target="_blank" rel="noopener noreferrer" className="fa fa-instagram"> </a></span>
            <span><a href="https://www.linkedin.com" target="_blank" rel="noopener noreferrer" className="fa fa-linkedin"> </a></span><br></br><br></br>
            <span style={{color: "white"}}><i className="fa fa-copyright">2020</i></span>
        </div>
    );
}

export default footer;
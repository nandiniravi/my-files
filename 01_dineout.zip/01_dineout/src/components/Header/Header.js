import React from 'react';
import './Header.css';
import logo from '../../assets/logo2.jpg';
import {NavLink} from 'react-router-dom';
import menuicon from '../../assets/menuicon.png';

const header = (props) => {
    return(
        <div className="Header">
            <NavLink to="/Home"><img src={logo} alt="Logo"/></NavLink>
            <NavLink to="/Home"><p>Dineout</p></NavLink>
            <NavLink to="/Home" exact activeClassName="selected"><span>Home</span></NavLink>
            <NavLink to="/Menu" exact activeClassName="selected"><span>Menu</span></NavLink>
            <NavLink to="/Events" exact activeClassName="selected"><span>Events</span></NavLink>
            <NavLink to="/Cart" exact activeClassName="selected"><span>Your Cart</span></NavLink>
            <NavLink to="/Contact-us" exact activeClassName="selected"><span>Contact Us</span></NavLink>
            <div className="Sidebar" onClick={props.showSidebar}><img src={menuicon} alt="Menu"/></div>
        </div>
    );
}

export default header;

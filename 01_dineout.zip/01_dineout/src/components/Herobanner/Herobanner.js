import React from 'react';
import Herobanner from '../../assets/hero-banner.jpg';
import './Herobanner.css';

const herobanner = () =>{
    return(
        <div className="Herobanner">
            <img src={Herobanner} alt="Hero Banner" />
            <h1>Dineout</h1>
            <p>A perfect place to have your favourite cuisine with your loved ones. A great ambience, authentic food, multiple cuisines from the most skilled culinary experts, exotic desserts, and exquisite beverages. Oldest wines, handpicked whiskies, and cocktails are our specialities. A party hall for all celebrations such as Birthdays, Anniversaries, Engagements are in offering! It's time to experience the richness and grandeur of Dineout!</p>
        </div>
    );
}

export default herobanner;
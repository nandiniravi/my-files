// import React from 'react';

const layout = (props) => {
    return (props.children);
}

export default layout;
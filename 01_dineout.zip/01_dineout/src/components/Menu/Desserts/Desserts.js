import React from 'react';
import banana from '../../../assets/banana-split.jpg'
import apple from '../../../assets/apple-pie.jpg'
import brownies from '../../../assets/brownies.jpg'
import snowballs from '../../../assets/icecream-snowballs.jpg'
import kheer from '../../../assets/kheer.jpg'
import './Desserts.css';

const desserts = (props) => {
    const myArray = [
        {   id: 1,
            name:"Banana Splits",
            description: "The banana split is a timeless dessert that will never get old. There’s just something about the combination of creamy ice cream and bananas that people will never be able to resist, and when it is topped with a crunchy almond topping and rich chocolate sauce, all bets are off. That dessert is what this recipe from Food & Wine yields, and it proves that you don’t need to visit your favorite ice cream outpost to enjoy a decadent summer treat.",
            src:{banana},
            price: 800
        },
        {   id: 2,
            name: "Apple Pie",
            description: "Just when you thought apple pie couldn't get any better, this recipe raises the bar like no other. Truly our best-ever, make this classic for a get-together and you might not have any leftovers to bring home. Top off this warm, melt-in-your mouth pie with a sprinkle of cinnamon and a scoop of ice cream.",
            src:{apple},
            price: 800
        },
        {   id: 3,
            name: "Fudgy Chewy Brownies",
            description: "A balanced diet is a brownie in each hand - don't you agree? Decadently rich, fudgy and chewy - bake a batch and be your family's hero. These brownies are pure chocolate overload, perfect to bake on a lazy afternoon. Feels like death by chocolate!",
            src:{brownies},
            price: 800
        },
        {   id: 4,
            name: "Ice Cream Snowballs with Raspberry Sauce",
            description: "A less traditional ice cream dessert that is just as tasty, and even more easy. Try these ice cream with raspeberry sauce you want to mix up your dessert rotation. The perfect combination of vanilaa icecream and the raspberry sauce, sprinkled with white chocolate shreds will leave you asking for more and more. This is one of our signature dishes, a must try!",
            src:{snowballs},
            price: 800
        },
        {   id: 5,
            name: "Coconut Kheer",
            description: "This kheer is made in an extra luxurious way featuring a blend of rich and coconut milk, spruced up with nutty caramel and rose petals. We assure you, it will be hard to have just one bite of this heavenly dessert!",
            src:{kheer},
            price: 800
        }
    ];
    return(
        <div>
            <h1 style={{backgroundColor: "#69195B", fontWeight: "lighter", padding: "5px 0px 5px 0px"}}>Desserts</h1>
            {myArray.map(each => {return(
                <div className="Desserts" key={each.id}>
                    <div className="col-sm-12 col-md-12 col-lg-4">
                        <img src={Object.values(each.src)} alt={each.name}/>
                    </div>
                    <div className="col-sm-12 col-md-12 col-lg-8 Text">
                        <h3>{each.name}</h3>
                        <p>{each.description}</p>
                        <span>₹ {each.price}</span>
                        <button onClick={(event) => props.addtoCart(event, myArray[each.id-1])}>Add to Cart</button>
                    </div>
                </div>
            )})}
        </div>
    );
};

export default desserts;
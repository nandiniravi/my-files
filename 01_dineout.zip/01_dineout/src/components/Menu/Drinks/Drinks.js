import React from 'react';
import axios from 'axios';
import Loader from '../../Loader/Loader';
import beer from '../../../assets/beer.jpg';
import './Drinks.css';

class Drinks extends React.Component{
        state = {
            loader: true,
            myArray: ''
        }
    
    componentDidMount() {
        axios.get('https://api.punkapi.com/v2/beers',true)
            .then(response => {
                let data = response.data;
                let myData = data.slice(0,10);
                this.setState({loader: false, myArray : myData});    
            }
        )            
    }
    render(){
        let myArray = this.state.myArray;
        // console.log(myArray);
        
        let myElement = null;
        if (this.state.myArray){
            myElement = myArray.map(each => {
                return(
                    <div className="Drinks" key={each.id}>
                        <div className="col-sm-12 col-md-12 col-lg-4">
                            <img src={beer} alt="Beer"/>
                        </div>
                        <div className="col-sm-12 col-md-12 col-lg-8 Text">
                            <h3>{each.name} - {each.tagline}</h3>
                            <p>{each.description}</p>
                            <span>₹ 1000</span>
                        </div>
                    </div>
                )
            });
        }
            
        
        let loader = null;
        if (this.state.loader)
            loader = <Loader/>
        else
            loader = null;

        // console.log(myElement);
        return(
            <div>
                <h1 style={{backgroundColor: "#900C3F", fontWeight: "lighter", padding: "5px 0px 5px 0px"}}>Drinks</h1>
                {myElement}
                {loader}
            </div>
        );
    }
}

export default Drinks;
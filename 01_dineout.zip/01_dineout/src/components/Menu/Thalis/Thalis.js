import React from 'react';
import andhra from '../../../assets/andhra-thali.jpg';
import chettinad from '../../../assets/chettinad-thali.jpg';
import kannada from '../../../assets/kannada-thali.jpg';
import gujarati from '../../../assets/gujarati-thali.jpeg';
import maharashtrian from '../../../assets/maharashtrian-thali.jpg';
import kerala from '../../../assets/kerala-thali.jpg';
import punjabi from '../../../assets/punjabi-thali.jpg';
import tamil from '../../../assets/tamil-thali.jpg';
import './Thalis.css';

const thalis = (props) => {
    let myArray = [
        {   id: 1,
            name: "Andhra Thali",
            description: "A quintessential Andhra thali is complete only when served on a banana leaf. An Andhra meal begins with a liberal dose of hot neyyi (ghee) served on piping hot rice along with mudda pappu (lentil). This is followed by charu ( a version of rasam), avakaya (mango pickle), parippu podi (powdered lentil with spices), vankaya kothamira kaaram (brinjal preparation), dondakayya veppudu (an ivy gourd preparation), before finishing off with a sumptuous dose of perugu (curd rice).",
            price: 1500,
            src : {andhra}
        },
        {   id: 2,
            name: "Chettinad Thali",
            description: "One of the spiciest and most aromatic thalis in India, the Chettinad thali has a distinctive place on the culinary map of the country. The fiery thali from Tamil Nadu includes murungakkai kara kozhambu (drumstick sambar), palakkai pirattal (raw jackfruit stir fry), kootu (lentil with vegetables), poriyal (dry vegetable), meen kuzhambu (fish curry), kozhi varuval (pepper chicken), appalam (papadam), rice, curd and pickle. Simple, spicy and very traditional!",
            price: 1500,
            src : {chettinad}
        },
        {   id: 3,
            name: "Kannadiga Oota Thali",
            description: "A typical Kannadiga Oota (Karnataka thali) is a beautiful blend of different flavours. Brimming with variety, this thali includes jolada roti (sorghum flatbread), akki roti (rice flatbread), padavalkayi masala (snakegourd curry), badane ennegai (stuffed brinjal), ranjaka (chilli-garlic chutney), gattisoppu (lentils and greens), mirchi bhajji (chilli fritters), kosambari (moong dal salad) and a bowl of homemade yoghurt.",
            price: 1500,
            src : {kannada}
        },
        {   id: 4,
            name: "Kathiawadi Thali",
            description: "Straight from the heart of Kathiawad, the classic Gujarati thali has much to offer. Most Gujarati dishes have a subtle sweet taste to them that makes them truly distinct from other Indian cuisines. This thali includes khatta dhokla (Gujarati snack), gajar mirch sambhaar (pickled carrots and capsicum), sev tamatar nu shaak (sweet and spicy tomato gravy), rigna palak nu shaak (spinach in brinjal curry), dal dhokli (dhokla in lentils), Kathiawadi stuffed onion, methi thepla ( a flatbread), kadhi khichdi, kesar shrikhand (saffron flavoured yoghurt sweet) and chaas (buttermilk). If you are lucky and its mango season, this thali will also be accompanied by a luscious aamras (mango pulp) dip.",
            price: 1500,
            src : {gujarati}
        },
        {   id: 5,
            name: "Maharashtrian Thali",
            description: "The Maharashtrian thali beautifully showcases the traditional and scrumptious staples of the state. Ranging from mild to very spicy, this lip smacking thali includes rice, bhakri roti (a millet flatbread), bharli vangi (stuffed brinjal), amti (spicy tangy tur lentil), pitla ( thick chickpea flour curry), kothimbir wadi (corainder cutlet), chawli chi usal (black eyed beans curry), pandhra rassa (chicken in white gravy), mutton kolhapuri (fiery mutton gravy), kosimbir (salad in yoghurt), and kheer (rice pudding).",
            price: 1500,
            src : {maharashtrian}
        },
        {   id: 6,
            name: "Kerala Sadhya Thali",
            description: "A multi course meal served traditionally on banana leaf, the sadhya or traditional feast is an integral part of Onam, the biggest festival of Kerala. The sadhya thali includes a variety of traditional dishes like sambhar, parippu curry (lentil curry), puliserry (cucumber in yoghurt), olan (white gourd in coconut milk), aviyal (mixed vegetables), thoran (veg stir fry), kalan (flavoured yoghurt curry), kichadi/pachadi (cucumber and coconut in yoghurt), as well as scrumptious desserts like ada pradhaman (rice and jaggery pudding) and sharkara varatti (banana chips with jaggery).",
            price: 1500,
            src : {kerala}
        },
        {   id: 7,
            name: "Punjabi Thali",
            description: "Punjab is a state synonymous with food and its thali is a lot like its people – rich, robust and full of life. Bold textures and hearty ingredients are what make up this popular thali that includes Amritsari aloo kulcha (stuffed flatbread) or naan, kadhi pakode (fritters in youghurt gravy), pindi chole (spicy chickpea curry), shahi paneer (rich cottage cheese gravy), jeera rice, dal makhni (black lentil) and sweet lassi. The much loved star delicacies of the non-veg platter are butter chicken and Amritsari machchi (deep fried fish).",
            price: 1500,
            src : {punjabi}
        },
        {   id: 8,
            name: "Tamil Sappadu",
            description: "There is no classic Tamil thali as each district and community in the state has its own signature recipes but the sappadu does have some much loved staples. They include poriyals (curries), kootu (mixed vegetable), mangai pachadi (mangoes with tur dal), paavakai (stir fried bitter gourd), kuzhambu (stews), thakkali rasam, chinna vengayam (small onion) sambar, thayir (curd rice) and utterly delicious pal payasam (rice pudding). Add this to the culinary specialties of each district and you know why this thali promises to be a gastronomic adventure!",
            price: 1500,
            src : {tamil}
        }
    ];
    return(
        <div>
            <h1 style={{backgroundColor: "goldenrod", fontWeight: "lighter", padding: "5px 0px 5px 0px"}}>Thalis</h1>
            {myArray.map(each => {
                return(
                <div className="Thalis" key={each.id}>
                    <div className="col-sm-12 col-md-12 col-lg-4">
                        <img src={Object.values(each.src)} alt={each.name}/>
                    </div>
                    <div className="col-sm-12 col-md-12 col-lg-8 Text">
                        <h3>{each.name}</h3>
                        <p>{each.description}</p>
                        <span>₹ {each.price}</span>
                        <button onClick={(event) => props.addtoCart(event, myArray[each.id-1])}>Add to Cart</button>
                    </div>
                </div>
            )})}
        </div>
    );
};

export default thalis;
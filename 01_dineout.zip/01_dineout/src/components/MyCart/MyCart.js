import React from 'react';
import './MyCart.css';

const mycart = (props) => {
    if (props.myCartArray.length === 0){
        return (
            <div>
                <div className="MyCart" style={{padding: "20%"}}>
                    <p>Your cart is currently empty!</p>
                </div><br></br><br></br>
            </div>
        );
    }
    else{
        return(
            <div className="MyCart">
                <h1 style={{backgroundColor: "#8E3793", fontWeight: "lighter", padding: "5px 0px 5px 0px"}}>Your Cart</h1>
                <p>(Please note that drinks are not available for takeaway!)</p><br></br>
                <div style={{paddingBottom: "5%"}}>
                    <table>
                        <thead>
                            <tr>
                                <th>Ordered Item</th>
                                <th>Item Price (in ₹)</th>
                                <th>Count</th>
                            </tr>
                        </thead>
                        <tbody>
                        {props.myCartArray.map(each => {
                            return(
                            <tr key={each.name+each.count}>
                                <td>{each.name}</td>
                                <td>{each.price}</td>
                                <td>{each.count}</td>
                            </tr>
                            );
                        })}
                        </tbody>
                    </table>
                </div>
                <h2 style={{backgroundColor: "#8E3793", fontWeight: "lighter", padding: "5px 0px 5px 0px"}}>Total Price: ₹ {props.totalPrice}</h2>
                <button onClick={props.checkout}>Checkout</button>
                <button onClick={props.clearCart}>Clear Cart</button>
            </div>
        );
    }
}

export default mycart;
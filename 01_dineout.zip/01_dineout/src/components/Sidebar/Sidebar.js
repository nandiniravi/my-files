import React from 'react';
import {NavLink} from 'react-router-dom';
import './Sidebar.css';

const sidebar = (props) => {
    return(
        <div>
            <div className="Backdrop" onClick={props.closeSidedrawer}>
            </div>
            <div className="SidebarContainer">
                <NavLink to="/Home" onClick={props.closeSidedrawer}><span>Home</span></NavLink>
                <NavLink to="/Menu" onClick={props.closeSidedrawer}><span>Menu</span></NavLink>
                <NavLink to="/Events" onClick={props.closeSidedrawer}><span>Events</span></NavLink>
                <NavLink to="/Cart" onClick={props.closeSidedrawer}><span>Your Cart</span></NavLink>
                <NavLink to="/Contact-us" onClick={props.closeSidedrawer}><span>Contact Us</span></NavLink>
            </div>
        </div>
    );
}

export default sidebar;

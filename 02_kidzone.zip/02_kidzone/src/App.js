import React, {useReducer} from 'react';
import './App.css';
import Layout from './components/Layout/Layout';
import Header from './components/Header/Header';
import Menu from './components/Menu/Menu';
import {Route} from 'react-router-dom';
import Footer from './components/Footer/Footer';
import Shapescolors from './components/Shapescolors/Shapescolors';
import Solarsystem from './components/Solarsystem/Solarsystem';
import Daysofweek from './components/Daysofweek/Daysofweek';
import Activity from './components/Activity/Activity';
import ContactUs from './components/ContactUs/ContactUs';
import LoginForm from './components/LoginForm/LoginForm';

export const UserContext = React.createContext();

// For Global state
const initialState = {loginStatus: false, loginId: ''};
const reducer = (state, action) => {
  // console.log(action.type);
    switch(action.type){
        case 'SUCCESS':
          return ({loginStatus: true, loginId: action.value});
        case 'FAILURE':
          return {loginStatus: false, loginId: ''};
        default:
          return initialState;
    }
}

function App() {
  // For Global state
  const [login, dispatch] = useReducer(reducer, initialState);

  return (
    <UserContext.Provider value={{login: login, dispatch: dispatch}}>
      <div className="App">
        <Layout>
          <Header/>
          <Route path="/Home" exact component={Menu}/>
          <Route path="/Basics" exact component={Shapescolors}/>
          <Route path="/Intermediate" exact component={Daysofweek}/>
          <Route path="/Advanced" exact component={Solarsystem}/>
          <Route path="/Activity" exact component={Activity}/>
          <Route path="/ContactUs" exact component={ContactUs}/>
          <Route path="/Login" exact component={LoginForm}/>
          <Footer/>
        </Layout>
      </div>
      </UserContext.Provider>
   
  );
}

export default App;


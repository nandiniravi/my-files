import React, {useState} from 'react';
import './Activity.css';
import data from '../data';
import TickorCross from './TickorCross';

const Activity = () => {
    const [answers, setAnswers] = useState(['','','','','']);
    const [submitted, setSubmitted] = useState(false);

    const updateAnswersHandler = (event, id) => {
        const array = [...answers];
        array[id] = event.target.value;
        setAnswers([...array]);
        console.log(event.target.value);
    }

    const submitHandler = (event) => {
        // console.log(answers);
        event.preventDefault();
        setSubmitted(true);
    }
    
    return(
        <div>
            <h2 className="Quiz">Quiz</h2>
            <form onSubmit = {(event) => submitHandler(event)}>
                {data.activity1.map(each => {
                    return(
                        <div className="Questioncard" key={each.id}>
                            <p>{each.question}</p>
                            <input type='text'
                                value={answers[each.id]}
                                placeholder="Your answer here..."
                                onChange = {(event) => updateAnswersHandler(event, each.id)}
                            />
                            {submitted ? <TickorCross answer={data.activity1[each.id].answer.search(answers[each.id].toLowerCase()) >= 0 ? 'correct' : 'incorrect'}/> : null}
                            {submitted ? <p style={{marginTop: "1.5%"}}>Correct Answer: {each.displayAnswer}</p> : null}
                        </div>
                    );
                })}
                <br></br><br></br>
                <button className="Submit">Submit</button>
            </form>
            <br></br><br></br>
            {/* {submitted ? <p>You can click on Home to go back to the Home page</p> : null} */}
        </div>
    );
}
export default Activity;
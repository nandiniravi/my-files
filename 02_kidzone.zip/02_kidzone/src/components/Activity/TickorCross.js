import React from 'react';
import './Activity.css';

const TickorCross = (props) => {
    console.log(props.answer);
    if (props.answer === 'correct'){
        return (<i className="fa fa-check Tick"></i>);
    }
    else if (props.answer === 'incorrect'){
        return (<i className="fa fa-times Wrong"></i>); 
    }    
}

export default TickorCross;
import React, {useContext} from 'react';
import './ContactUs.css';
import logo1 from '../../assets/logo1.png';
import {UserContext} from '../../App';

const ContactUs = () => {
    const userDetails = useContext(UserContext);

    var offers;
    if(userDetails.login.loginStatus){
        // console.log(userDetails.login);
        
        offers = 
            <div>
                <h6>Hello {userDetails.login.loginId.split('-')[0]}, we have great offers for our members! Check them out now!</h6>
                <div className="col-sm-12 col-md-6 col-lg-4 Offer">
                    <h3>Summer Camp</h3>
                    <p>For kids aged 6 to 10</p>
                    <p>Duration: 6 weeks</p>
                    <h4>Discount of 10%</h4>
                </div>
                <div className="col-sm-12 col-md-6 col-lg-4 Offer">
                    <h3>Yoga Camp - Kids</h3>
                    <p>For kids aged 10 to 14</p>
                    <p>Duration: 3 weeks</p>
                    <h4>Discount of 20%</h4>
                </div>
            </div>;
    }
    else
        offers = null;
    return (
        <div className="ContactUsbg">
            {offers}
            <h1>Contact Us</h1><br></br>
            <p>You can visit us anytime and we are sure your kids are going to love KidZone!</p>
            <img src={logo1} alt="logo1" style={{borderRadius: "50%"}}/><br></br><br></br>
            <h3>KidZone</h3>            
            <p>No. 6, Paradise Towers,<br></br>
                8th Cross street,<br></br>
                Mylapore,<br></br>
                Chennai - 600 004<br></br><br></br>
                <span>
                    <i className="fa fa-phone"></i>&nbsp;&nbsp;&nbsp;&nbsp;+91 90000 000000<br></br></span>
                    <span><i className="fa fa-envelope"></i>&nbsp;&nbsp;&nbsp;&nbsp;<a href="mailto: kidzone@mail.com" style={{color: "white"}}>kidzone@mail.com</a>
                </span>
            </p>
        </div>
    );
}

export default ContactUs;
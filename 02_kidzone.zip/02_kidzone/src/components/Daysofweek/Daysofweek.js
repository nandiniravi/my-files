import React, {useState} from 'react';
import './Daysofweek.css';
import data from '../data';
import clock from '../../assets/clock.jpg';
import clock2 from '../../assets/clock2.jpg';

const Days = () => {
    const [showExample, setShowExample] = useState(false);

    var example;
    if (showExample)
        example = <div>
                    <img src={clock} alt="clock" style={{width: "40%", height: "60%", border: "1px solid #fff", borderRadius: "5%", marginTop: "20px", marginBottom: "20px"}}/>
                    <h6>This clock shows 04:00:40 hrs.</h6>
                </div>;
    else
        example = null;

    return(
        <div>
            <h2 className="DaysofWeek" style={{textAlign : "Center"}}>Days of Week</h2>
            <div className="DaysofweekText">
                <div className="Count">
                    7 <span style={{marginRight: "1%"}}>&#8667;</span>
                </div>
                <div>
                    {data.daysofweek.map(each => {
                        return <div className="Day">{each}</div>;
                    })}
                </div>
            </div>
            <h2 className="DaysofWeek" style={{textAlign : "Center"}}>Months of Year</h2>
            <div className="DaysofweekText">
                <div className="Count">
                    12 <span> &#8667;</span>
                </div>
                <div>
                    {data.monthsoftheyear.map(each => {
                        return <div className="Day">{each.month} - has {each.days} days</div>;
                    })}
                </div>
            </div>
            <h2 className="DaysofWeek" style={{textAlign : "Center"}}>Time</h2>
            <div className="DaysofweekText" >
                <div>A clock has 12 numbers for each hour from 00:00 hours to 12:00 hours and 2 hands as shown below: (Some clocks have a third hand - Seconds hand)<br></br><br></br>
                    <img src={clock2} alt="clock-details" style={{width: "85%"}}/>
                    <div className="Example" onClick={() => setShowExample(!showExample)}>Example</div><br></br><br></br>
                     {example}
                </div>
            </div>
        </div>
    );
}

export default Days;
import React, {useState, useContext} from 'react';
import './Header.css';
import logo1 from '../../assets/logo1.png';
import logo2 from '../../assets/logo2.png';
import {NavLink} from 'react-router-dom';
import {UserContext} from '../../App';

const Header = () => {
    const [showMenu, setShowMenu] = useState(false);
    const userDetails = useContext(UserContext);
    // console.log(userDetails.login.loginStatus);

    const Sidedrawer =     
        <div className="Sidedrawer">
            <div className="Backdrop" onClick={() => setShowMenu(false)}></div>
            <div className="Menulist">
            <ul>
                <NavLink to="/Home" exact activeClassName="selectedMob" onClick={() => setShowMenu(false)}><li>Home</li></NavLink>
                <NavLink to="/Activity" exact activeClassName="selectedMob" onClick={() => setShowMenu(false)}><li>Activity</li></NavLink>
                {userDetails.login.loginStatus
                    ? <NavLink to="/Home" onClick={() => setShowMenu(false)}><li onClick={() => userDetails.dispatch({type: 'FAILURE'})}>Logout</li></NavLink>
                    : <NavLink to="/Login" exact activeClassName="selectedMob" onClick={() => setShowMenu(false)}><li>Login</li></NavLink>
                }
                <NavLink to="/ContactUs" exact activeClassName="selectedMob" onClick={() => setShowMenu(false)}><li>Contact Us</li></NavLink> 
            </ul>
            </div>
        </div>;

    return (
        <React.Fragment>
        <div className="Header">
            <img src={logo1} alt="logo1" style={{float:"right", cursor: "initial"}} className="img-right"/>
            <NavLink to="/Home" exact><img src={logo2} alt="logo2"/></NavLink>
            <NavLink to="/Home" exact><h1>KidZone</h1></NavLink>
            <ul>
                <NavLink to="/Home" exact activeClassName="selected"><li>Home</li></NavLink>
                <NavLink to="/Activity" exact activeClassName="selected"><li>Activity</li></NavLink>
                {userDetails.login.loginStatus
                    ? <NavLink to="/Home"><li onClick={() => userDetails.dispatch({type: 'FAILURE'})}>Logout</li></NavLink>
                    : <NavLink to="/Login" exact activeClassName="selected"><li>Login</li></NavLink>
                }
                <NavLink to="/ContactUs" exact activeClassName="selected"><li>Contact Us</li></NavLink> 
            </ul>
            <i className="fa fa-bars MenuIcon" onClick={() => setShowMenu(!showMenu)}></i>
        </div>
        {showMenu ? Sidedrawer : null}
        </React.Fragment>
    );
}

export default Header;
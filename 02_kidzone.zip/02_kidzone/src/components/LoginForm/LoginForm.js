import React, {useState, useEffect, useContext} from 'react';
import './LoginForm.css';
import './SignupForm.css';
import SignupForm from './SignupForm';
import {Link} from 'react-router-dom';
import {UserContext} from '../../App';


const LoginForm = (props) => {
    const [login, setLogin] = useState({loginId: '', password: ''});
    const [showSignupForm, setShowSignupForm] = useState(false);
    const [usersList, setUsersList] = useState({});
    const [showConfirmation, setShowConfirmation] = useState(false);
    const [showErrorMsg, setShowErrorMsg] = useState(false);

    const userLoginStatus = useContext(UserContext);    

    useEffect(() => {
        fetch('https://react-kidzone.firebaseio.com/users.json')
        .then(response => {
            return response.json();
        })
        .then(data => {
            setUsersList(Object.values(data));
        })
    }, []);
    
    const loginHandler = (event) => {
        event.preventDefault();
        const result = usersList.filter(each => each.loginId === login.loginId && each.password === login.password);
        if(result.length === 1){
            setShowConfirmation(true);
            userLoginStatus.dispatch({type: 'SUCCESS', value: login.loginId});
            console.log('You have successfully logged in');
        }
        else{
            setShowErrorMsg(true);
        }
    }

    const showSignupFormHandler = (event) => {
        event.preventDefault();
        setShowSignupForm(true);
    }

    const showConfirmationMsg = 
        <div className="Creds">
            <p>You have successfully logged in to KidZone!</p>        
            <Link to="/Home"><button onClick={() => setShowConfirmation(false)}>Okay</button></Link>
        </div>;

    const ErrorMsg = 
        <div className="Creds">
            <p>Login ID or password entered is incorrect. Please try again. If you do not have an account, you can create by clicking on Sign up</p>        
            <Link to="/Home"><button onClick={() => setShowErrorMsg(false)}>Okay</button></Link>
        </div>;

    return(
        <div>
            <div className="Login">
                <h3 style={{fontStyle: "normal"}}>Login</h3>
                <form>
                    <input type="text" 
                            placeholder="Login ID"
                            value={login.loginId}
                            onChange={(event) => setLogin({...login, loginId : event.target.value})}
                            /><br></br>
                    <input type="password"
                            placeholder="Password"
                            value={login.password}
                            onChange={(event) => setLogin({...login,password : event.target.value})}
                            /><br></br>
                    <button className="Loginbutton" onClick={loginHandler}>Login</button>
                    <button className="Loginbutton" onClick={(event) => showSignupFormHandler(event)}>Sign up</button>
                    <p>If you have not already registered, you can register by clicking on Sign up.</p><br></br>
                </form>
                {showConfirmation ? showConfirmationMsg : null}
                {showErrorMsg ? ErrorMsg : null}
            </div>
           
            {showSignupForm ? <SignupForm showSignupFormHandler={() => setShowSignupForm(false)} /> : null}
        </div>
    );
}

export default LoginForm;
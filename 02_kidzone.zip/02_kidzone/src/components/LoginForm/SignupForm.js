import React, {useState} from 'react';
import './LoginForm.css';
import './SignupForm.css';
import Loader from '../Loader/Loader';
import {Link} from 'react-router-dom';

const SignupForm = (props) => {
    const [newUser, setNewUser] = useState({username: '', contact: '', email: '', loginId: '', password: ''});
    const [showCred, setShowCred] = useState(false);
    const [showLoader, setshowLoader] = useState(false);
    const [showError, setshowError] = useState(false);

    const updateUserAccount = (event) => {
        event.preventDefault();
        if(newUser.username !== '' && newUser.contact !== '' && newUser.email !== ''){
            setshowLoader(true);
            fetch('https://react-kidzone.firebaseio.com/users.json', {
                method: 'POST',
                body: JSON.stringify(newUser),
                headers: {'Content-Type' : 'application/json'}
            }).then(response => {
                setshowLoader(false);
                setShowCred(true);
                // console.log(newUser);
            });
        }
        else{
            setshowError(true);
        }
    }

    const hideCred = () => {
        setShowCred(false);
        setNewUser({username: '', contact: '', email: '', loginId: '', password: ''});
        props.showSignupFormHandler();
    }

    const showLoginCreds = 
            <div className="Creds">
                <p>You have successfully created an account with Kidzone. Your login details are given below:</p>
                <p>Your login ID: {newUser.loginId}</p>
                <p>Your password: {newUser.password}</p>
                <Link to="/Home"><button onClick={() => hideCred()}>Okay</button></Link>
            </div>

    const showErrorMessage = 
            <div className="Creds">
            <p>Please fill in the requested details for account creation!</p>
            <button onClick={() => setshowError(false)}>Okay</button>
        </div>

    
    return(
        <div className="Login">
            <h3 style={{fontStyle: "normal"}}>Account Creation Form</h3>
            <form>
                <input type="text"
                        placeholder="Your Name"
                        value={newUser.name}
                        onChange={(event) => setNewUser({...newUser, username: event.target.value, loginId: event.target.value.toLowerCase()+'-kidzone', password: event.target.value.toLowerCase() + '@2020'})}/><br></br>
                <input type="tel"
                        placeholder="Your Contact"
                        value={newUser.name}
                        onChange={(event) => setNewUser({...newUser, contact: event.target.value})}/><br></br>
                <input type="email"
                        placeholder="Your Email"
                        value={newUser.email}
                        onChange={(event) => setNewUser({...newUser, email: event.target.value})}/><br></br>
                <button 
                        className="Loginbutton"
                        onClick={(event) => updateUserAccount(event)}
                        >Create Account</button>
            </form>
            {showLoader ? <Loader/> : null}
            {showCred ? showLoginCreds : null}
            {showError ? showErrorMessage: null}
        </div>
    );
}

export default SignupForm;
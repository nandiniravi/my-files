import React, {useState} from 'react';
import './Menu.css';
import {Link} from 'react-router-dom';

const Menu = () => {
    const [showBasics, setshowBasics] = useState(false);
    const [showIntermediate, setshowIntermediate] = useState(false);
    const [showAdvanced, setshowAdvanced] = useState(false);

    const myMenu = {
        Basics: [
            {id: 0, title: 'Shapes & Colors', link: '/Basics'},
            {id: 1, title: 'Numbers & Alphabets', link: '/Basics'},
        ],
        Intermediate: [
            {id: 2, title: 'Days of the Week', link: '/Intermediate'},
            {id: 3, title: 'Months of the year', link: '/Intermediate'},
            {id: 4, title: 'Time', link: '/Intermediate'}
        ],
        Advanced: [
            {id: 5, title: 'Solar System', link: '/Advanced'},
            {id: 6, title: 'Daily Habits', link: '/Advanced'}
        ]
    };
    
        
        if(showBasics){
            var basicsMenu = myMenu.Basics.map(each => {
                return <Link to={each.link} key={each.title}>
                            <div className="Menu-elements">
                                <p>{each.title}</p>
                            </div>
                        </Link>
            });
        }
        else
            basicsMenu = null;
            
        if(showIntermediate){
            var intermediateMenu = 
                myMenu.Intermediate.map(each => {
                    return <Link to={each.link} key={each.title}>
                                <div className="Menu-elements">
                                    <p>{each.title}</p>
                                </div>
                            </Link>
            });
        }
        else
            intermediateMenu = null;

        
        if(showAdvanced){
            var advancedMenu = 
                myMenu.Advanced.map(each => {
                    return <Link to={each.link} key={each.title}>
                                <div className="Menu-elements">
                                    <p>{each.title}</p>
                                </div>
                            </Link>
            });
        }
        else
            advancedMenu = null;



    return(
        <React.Fragment>
            <div className="Menu-background" style={{opacity: "1.0"}}>
                <p style={{color: "#fff"}}>Play is far more powerful for children than many parents realize. It’s actually the key to learning. Researchers and educators across the world have found that play can help enrich learning and develop key skills such as inquiry, expression, experimentation, and teamwork. Play gives the child a choice about what he or she wants to do, what is fun and enjoyable for the child. Children
                evolve spontaneously during activities, they are driven by intrinsic motivation.</p>
                <p style={{color: "#fff"}}>We at KidZone understand this and provide a learning experience for the kids that is enjoyable and fun. Most kids are visual learners and we adapt this learning strategy to educate the kids, which not only enhances their cognitive abilities but also makes learning fun! KidZone provides an environment where kids can experiment and try new ideas.</p>
            </div>
            <div className="Menu-background">
                <h4>Time to explore!</h4><br></br>
                <div onClick={() => {setshowBasics(!showBasics)}}><h5>Basics<i className='fa fa-sort' style={{float: "right"}}></i></h5></div>
                {basicsMenu}
                <div onClick={() => setshowIntermediate(!showIntermediate)}><h5>Intermediate<i className='fa fa-sort' style={{float: "right"}}></i></h5></div>
                {intermediateMenu}
                <div onClick={() => setshowAdvanced(!showAdvanced)}><h5>Advanced<i className='fa fa-sort' style={{float: "right"}}></i></h5></div>
                {advancedMenu}
            </div>
        </React.Fragment>
        );
   
}

export default Menu;
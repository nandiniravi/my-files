import React, {useState} from 'react';
import './NumbersandAlphabets.css';
import data from '../data';

const NumbersandAlphabets = () => {
    const [letterId, setletterId] = useState(0);

    const showExampleHandler = (selectedLetterId) => {
        setletterId(selectedLetterId-1);
    }
    
    var letterExample;
    
    if (setletterId){
        letterExample = <h5 style={{backgroundColor: "#F6E453", color: "midnightblue", padding: "2%", marginBottom: "2%"}}>
            Letter {data.letters[letterId].letter[0]} can be used as in: {data.letters[letterId].example}
            </h5>
    }
    else
    letterExample = null;
   
    return (
        <div>
            <div>
            <h2 className="NumberTitle" style={{backgroundColor: "#35739F", color: "#fff"}}>Numbers</h2>
            {data.numbers.map(eachNumber => {
                let i=0;
                let k=[];
                while(i<eachNumber.value){
                    k.push(i);
                    i=i+1;
                }
                return(
                    <div className="NumberRow" key={eachNumber.value}>
                        <span className='digit'>{eachNumber.value}</span>
                        {k.map(eachk => {
                            return(<span className="image">{eachNumber.img}</span>);
                        })}
                        <span className="inwords">{eachNumber.inwords}</span>   
                    </div>  
                );
            })}
            </div>
            <div>
                <h2 className="NumberTitle">Alphabets</h2>
                <div style={{backgroundColor: "#F6E453", opacity: "0.95"}}>
                    {data.letters.map(each => {
                        return <p className="Letter" key={each.id} onClick={() => showExampleHandler(each.id)}>{each.letter}</p>
                    })}
                    {letterExample}
                </div>
            </div>
        </div>
    );
};

export default NumbersandAlphabets;
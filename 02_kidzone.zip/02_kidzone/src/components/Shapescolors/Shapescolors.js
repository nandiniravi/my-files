import React, {useState} from 'react';
import data from '../data';
import './Shapescolors.css';
import colorwheel from '../../assets/colorwheel.jpg';
import NumbersandAlphabets from '../NumbersandAlphabets/NumbersandAlphabets';

const Shapescolors = () => {
    const [colorId, setColorId] = useState('');
    const [showColorDetails, setshowColorDetails] = useState(false);
    const [seeColorWheel, setseeColorWheel] = useState(false);

    const showObjectHandler = (selectedColorId) => {
       setColorId(selectedColorId);
       setshowColorDetails(true);
    }

    const showColorWheelHandler = () => {
        // console.log(seeColorWheel);
        setseeColorWheel(!seeColorWheel);
    }

    var colorDetails;
    if (showColorDetails){
        colorDetails = 
        <div className="Colordetails">
            <img src={Object.values(data.colors[colorId].url)} alt={data.colors[colorId].title}/>
            <div>
                <h3>{data.colors[colorId].title}</h3>
                <p>{data.colors[colorId].description}</p>
                <ul>{data.colors[colorId].list.map(each => {
                    return <li key={each}>{each}</li>
                })}</ul>
            </div>
        </div>
    }
    else
        colorDetails = null;

    var colorWheel;
    if(seeColorWheel){
        colorWheel = <div style={{backgroundColor: "#2BBEBB",marginTop: "2%", padding: "2%"}}><img src={colorwheel} alt="color-wheel" className="ColorWheelImg"/></div>
    }
    else
        colorWheel = null;

    return(
        <div>
            <div>
                <h2 className="Title">Shapes</h2>
                {data.shapes.map(each => {
                    return(
                        <div className="col-lg-3 col-md-6 col-sm-10 ShapeCard" key={each.id}>
                            <h3>{each.shape}</h3>
                            <img src={Object.values(each.url)} alt={each.shape}/><br></br>
                            <p>{each.description}</p>
                        </div>
                    );
                })}
            </div>
            <div>
                <h2 className="Title" style={{backgroundColor: "#2BBEBB"}}>Colors</h2>
                {data.colors.map(each => {
                    return(
                        <div className="col-lg-3 col-md-6 col-sm-12 ColorCard" 
                            key={each.id}
                            onClick={() => showObjectHandler(each.id)}>{each.title}</div>
                    );
                })}
            </div>
            <div className="Colorwheelbutton" onClick={() => {showColorWheelHandler()}}>Color Wheel</div>
            {colorDetails}
            {colorWheel}
            <NumbersandAlphabets/>
        </div>
    );
}

export default Shapescolors;
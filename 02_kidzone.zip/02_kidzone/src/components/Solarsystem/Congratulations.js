import React from 'react';
import './Congratulations.css';

const Congratulations = (props) => {
    var message = <p>Start following the daily habits and you will see notable differences in your life!</p>;
    return (
        <div className="Congratulations">
            {message}
            <div onClick={props.hideMessageHandler}>Okay</div>
        </div>
        );
}

export default Congratulations;
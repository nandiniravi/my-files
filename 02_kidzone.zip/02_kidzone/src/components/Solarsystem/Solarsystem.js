import React, {useState} from 'react';
import solarsystem from '../../assets/solarsystem.gif';
import './Solarsystem.css';
import data from '../data';
import Congratulations from './Congratulations';

const Solarsystem = () => {
    const [currentPlanet, setcurrentPlanet] = useState(0);
    const [habits, setHabits] = useState('yes');
    const [showMessage, setShowMessage] = useState(false);

    const nextArrowHandler = () => {
        if(currentPlanet !== 8){
            setcurrentPlanet(currentPlanet +1);
        }
        else if(currentPlanet === 8){
            setcurrentPlanet(0);    
        }
    }

    const previousArrowHandler = () => {
        if(currentPlanet !== 0){
            setcurrentPlanet(currentPlanet -1);
        }
        
        else if(currentPlanet === 0){
            setcurrentPlanet(8);   
        }         
    }
    
    var planetTitle = data.planets[currentPlanet].planet;
    var planetDescription =  <p>{data.planets[currentPlanet].description}</p>;

    const updateFormHandler = (event, id) => {
        setHabits(event.target.value);
    }

    const checkHandler = () => {
        setShowMessage(true);
        setHabits('yes');
    }

    const hideMessage = () => {
        setShowMessage(false);
        setHabits('yes');
    }

    var checkMessage;
    if(showMessage)
        checkMessage = <Congratulations
                            hideMessageHandler={() => hideMessage()}/>
    else
        checkMessage = null;
        

    return(
        <div>
            <h2 className="SolarsystemTitle" style={{textAlign : "Center"}}>Solar System</h2>
            <div className="SolarsytemText">
                <img src={solarsystem} alt="Solar system"/>
                <div className="Text">
                    <h2 style={{display: "inline-block", width: "100%", textAlign : "Center"}}>Solar System</h2><br></br><br></br>
                    <p>Our planetary system is located in an outer spiral arm of the Milky Way galaxy. <br></br>Our solar system consists of our star, the Sun, and everything bound to it by gravity — the planets Mercury, Venus, Earth, Mars, Jupiter, Saturn, Uranus and Neptune, dwarf planets such as Pluto, dozens of moons and millions of asteroids, comets and meteoroids.<br></br><br></br> Beyond our own solar system, we have discovered thousands of planetary systems orbiting other stars in the Milky Way. Milky Way is one of perhaps 100 billion galaxies in the universe.</p>
                </div>
            </div>
            <div className="Carousel">  
                <div>
                    <h3>
                        <span onClick={() => previousArrowHandler()}>‹</span>
                        {planetTitle}
                        <span onClick={() => nextArrowHandler()}>›</span>
                    </h3>
                    {planetDescription}
                </div>
            </div>

            <h2 className="SolarsystemTitle" style={{textAlign : "Center"}}>Daily Habits</h2>
            <div className="Dailyhabits">
                {data.dailyhabits.map(each => {
                    return (
                    <div key={each.id}>
                        <p>{each.question}</p>
                        <select name="YesorNo"
                            onChange={(event) => updateFormHandler(event,each.id)} >
                            <option value=""></option>
                            <option value="yes">Yes</option>
                            <option value="no">No</option>
                        </select>
                    </div>);
                })}
                <br></br>
                <div className="Check" onClick={() => checkHandler()}>Check</div>
                {checkMessage}
            </div>
        </div>
    );
}

export default Solarsystem;
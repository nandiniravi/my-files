import triangle from '../assets/triangle1.png';
import square from '../assets/square2.png';
import rectangle from '../assets/rectangle2.png';
import pentagon from '../assets/pentagon1.png';
import hexagon from '../assets/hexagon1.png';
import heptagon from '../assets/heptagon.png';
import octagon from '../assets/octagon1.png';
import circle from '../assets/circle1.png';
import primarycolors from '../assets/primarycolors.png';
import secondarycolors from '../assets/secondarycolors.gif';
import tertiarycolors from '../assets/tertiarycolors.jpg';


const data = {
    shapes : [
        {   id: 1,
            shape: "Triangle",
            description: "A triangle has 3 sides. Sum of the internal angles is 180 degrees.",
            url: {triangle}
        },
        {   id: 2,
            shape: "Square",
            description: "A square has 4 sides of equal length. Sum of the angles is 360 degrees.",
            url: {square}
        },
        {   id: 3,
            shape: "Rectangle",
            description: "A rectangle has 4 sides, opposite sides are of equal length.",
            url: {rectangle}
        },
        {   id: 4,
            shape: "Pentagon",
            description: "A pentagon has 5 sides.",
            url: {pentagon}
        },
        {   id: 5,
            shape: "Hexagon",
            description: "A hexagon has 6 sides.",
            url: {hexagon}
        },
        {   id: 6,
            shape: "Heptagon",
            description: "A heptagon has 7 sides.",
            url: {heptagon}
        },
        {   id: 7,
            shape: "Octagon",
            description: "An octagon has 8 sides.",
            url: {octagon}
        },
        {   id: 8,
            shape: "Circle",
            description: "A circle has no sides.",
            url: {circle}
        }
    ],
    colors : [
        {
            id: 0,
            title: "Primary Colors",
            description: "There are 3 Primary Colors - Yellow, Red and Blue. They are at the top of any color structure. That's because you can think of the three Primaries as the original parents of all the future generations of colors. In Theory, Primary Colors are the root of every other color.",
            list: ["Red", "Yellow", "Blue"],
            url: {primarycolors}
        },
        {   id: 1,
            title: "Secondary Colors",
            description: "There are three Secondary colors - Orange, Violet and Green. Think of the Secondary colors as the children of the each pair of three Primary colors. ​In color theory, we are taught that the Secondary colors are mixed like this: ",
            list : ["Yellow  +  Red  =  Orange", "Red  +  Blue  =  Violet", "Blue  +  Yellow  =  Green"],
            url: {secondarycolors}
        },
        {
            id: 2,
            title: "Tertiary Colors",
            description: "There are six Tertiary Colors. Think of these as the six grandchildren of the Primary Colors. Again, Color Theory teaches us that each Tertiary color is the result of one Primary Color mixed with one of its nearest Secondary colors. Therefore, we end up with a new color somewhere in between.",
            list: ["Yellow  +  Green  =  Yellow-Green", "Yellow  +  Orange  =  Yellow-Orange", "Red  +  Orange  =  Red-Orange", "Blue  +  Green  =  Blue-Green", "Blue  +  Violet  =  Blue-Violet", "Red  +  Violet  =  Red-Violet",],
            url: {tertiarycolors}
        }],
    numbers : [
        {value: 1, inwords : 'One', img: '🐵'},
        {value: 2, inwords : 'Two', img: '🐘'},
        {value: 3, inwords : 'Three', img: '🥝'},
        {value: 4, inwords : 'Four', img: '☃️'},
        {value: 5, inwords : 'Five', img: '🍓'},
        {value: 6, inwords : 'Six', img: '🍉'},
        {value: 7, inwords : 'Seven', img: '🥦'},
        {value: 8, inwords : 'Eight', img: '🍍'},
        {value: 9, inwords : 'Nine', img: '🚒'},
        {value: 10, inwords : 'Ten', img: '🚓'},
        ],
    letters : [
        {   id: 1,
            letter: "Aa",
            example: "Apple"
        },
        {   id: 2,
            letter: "Bb",
            example: "Ball"
        },
        {   id: 3,
            letter: "Cc",
            example: "Cat"
        },
        {   id: 4,
            letter: "Dd",
            example: "Dog"
        },
        {   id: 5,
            letter: "Ee",
            example: "Elephant"
        },
        {   id: 6,
            letter: "Ff",
            example: "Fan"
        },
        {   id: 7,
            letter: "Gg",
            example: "Grapes"
        },
        {   id: 8,
            letter: "Hh",
            example: "Horse"
        },
        {   id: 9,
            letter: "Ii",
            example: "Icecream"
        },
        {   id: 10,
            letter: "Jj",
            example: "Jam"
        },
        {   id: 11,
            letter: "Kk",
            example: "Kite"
        },
        {   id: 12,
            letter: "Ll",
            example: "Lion"
        },
        {   id: 13,
            letter: "Mm",
            example: "Monkey"
        },
        {   id: 14,
            letter: "Nn",
            example: "Nest"
        },
        {   id: 15,
            letter: "Oo",
            example: "Orange"
        },
        {   id: 16,
            letter: "Pp",
            example: "Peacock"
        },
        {   id: 17,
            letter: "Qq",
            example: "Queen"
        },
        {   id: 18,
            letter: "Rr",
            example: "Rain"
        },
        {   id: 19,
            letter: "Ss",
            example: "Sun"
        },
        {   id: 20,
            letter: "Tt",
            example: "Tiger"
        },
        {   id: 21,
            letter: "Uu",
            example: "Umbrella"
        },
        {   id: 22,
            letter: "Vv",
            example: "Violin"
        },
        {   id: 23,
            letter: "Ww",
            example: "Watch"
        },
        {   id: 24,
            letter: "Xx",
            example: "Xylophone"
        },
        {   id: 25,
            letter: "Yy",
            example: "Yatch"
        },
        {   id: 26,
            letter: "Zz",
            example: "Zebra"
        }
    ],
    planets : [
        {
            id: 0,
            planet: "Mercury",
            description: "The smallest planet in our solar system and nearest to the Sun, Mercury is only slightly larger than Earth's Moon. From the surface of Mercury, the Sun would appear more than three times as large as it does when viewed from Earth, and the sunlight would be as much as seven times brighter. Despite its proximity to the Sun, Mercury is not the hottest planet in our solar system."
        },
        {
            id: 1,
            planet: "Venus",
            description: "Second planet from the Sun and our closest planetary neighbor, Venus is similar in structure and size to Earth, but it is now a very different world. Venus spins slowly in the opposite direction most planets do. Its thick atmosphere traps heat in a runaway greenhouse effect, making it the hottest planet in our solar system—with surface temperatures hot enough to melt lead."
        },
        {
            id: 2,
            planet: "Earth",
            description: "Our home planet is the third planet from the Sun, and the only place we know of so far that’s inhabited by living things. While Earth is only the fifth largest planet in the solar system, it is the only world in our solar system with liquid water on the surface. Just slightly larger than nearby Venus, Earth is the biggest of the four planets closest to the Sun, all of which are made of rock and metal."
        },
        {
            id: 3,
            planet: "Mars",
            description: "The fourth planet from the Sun, Mars is a dusty, cold, desert world with a very thin atmosphere. This dynamic planet has seasons, polar ice caps and weather and canyons and extinct volcanoes, evidence it was once an even more active past. The Mars Orbiter Mission (MOM), also called Mangalyaan is a space probe orbiting Mars since 24 Sept, 2014. Research is on to check the possibility of life on Mars."
        },
        {
            id: 4,
            planet: "Jupiter",
            description: "Fifth in line from the Sun, Jupiter is, by far, the largest planet in the solar system – more than twice as massive as all the other planets combined. Jupiter's familiar stripes and swirls are actually cold, windy clouds of ammonia and water, floating in an atmosphere of hydrogen and helium. Jupiter’s iconic Great Red Spot is a giant storm bigger than Earth that has raged for hundreds of years."
        },
        {
            id: 5,
            planet: "Saturn",
            description: "Saturn is the sixth planet from the Sun and the second largest planet in our solar system. Adorned with thousands of beautiful ringlets, Saturn is unique among the planets. It is not the only planet to have rings—made of chunks of ice and rock—but none are as spectacular or as complicated as Saturn's. Like fellow gas giant Jupiter, Saturn is a massive ball made mostly of hydrogen and helium."
        },
        {
            id: 6,
            planet: "Uranus",
            description: "Uranus is the seventh planet from the Sun. Uranus is known as the “sideways planet” because it rotates on its side. Uranus was discovered in 1781 by William Herschel. Uranus was the first planet found using a telescope. Uranus is an Ice Giant planet and nearly four times larger than Earth. Uranus has 27 known moons, most of which are named after literary characters. Uranus is a ringed planet."
        },
        {
            id: 7,
            planet: "Neptune",
            description: "Dark, cold and whipped by supersonic winds, ice giant Neptune is the eighth and most distant planet in our solar system. More than 30 times as far from the Sun as Earth, Neptune is the only planet in our solar system not visible to the naked eye and the first predicted by mathematics before its discovery. In 2011 Neptune completed its first 165-year orbit since its discovery in 1846."
        },
        {
            id: 8,
            planet: "Pluto",
            description: "Pluto, once considered the ninth and most distant planet from the sun, is now the largest known dwarf planet in the solar system. It is also one of the largest known members of the Kuiper Belt, a shadowy zone beyond the orbit of Neptune thought to be populated by hundreds of thousands of rocky, icy bodies each larger than 62 miles  across, along with 1 trillion or more comets."
        }

    ],
    dailyhabits : [
        {
            id: 0,
            question: "Did you brush your teeth today?"
        },
        {
            id: 1,
            question: "Did you take bath today?"
        },
        {
            id: 2,
            question: "Did you wear fresh clothes today?"
        },
        {
            id: 3,
            question: "Did you offer a prayer today?"
        },
        {
            id: 4,
            question: "Did you wash your hands before having breakfast today?"
        },
        {
            id: 5,
            question: "Did you eat your breakfast and have milk today?"
        },
        {
            id: 6,
            question: "Did you prepare your school bag today?"
        },
        {
            id: 7,
            question: "Did you finish your homework today?"
        },
        {
            id: 8,
            question: "Did you have your lunch and dinner today?"
        },
        {
            id: 9,
            question: "Did you brush your teeth before going to bed today?"
        }  
    ],
    daysofweek : [
        'Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'
    ],
    monthsoftheyear: [
        {
            month: "January",
            days: 31
        },
        {
            month: "February",
            days: 28
        },
        {
            month: "March",
            days: 31
        },
        {
            month: "April",
            days: 30
        },
        {
            month: "May",
            days: 31
        },
        {
            month: "June",
            days: 30
        },
        {
            month: "July",
            days: 31
        },
        {
            month: "August",
            days: 31
        },
        {
            month: "September",
            days: 30
        },
        {
            month: "October",
            days: 31
        },
        {
            month: "November",
            days: 30
        },
        {
            month: "December",
            days: 31
        },
    ],
    activity1: [
        {   
            id: 0,
            question : "What is the shape of a full moon?",
            answer: "circle/round",
            displayAnswer: 'The full moon is round or circular in shape!'
        },
        {   
            id: 1,
            question : "What is the color of sunflower?",
            answer: "yellow",
            displayAnswer: 'A sunflower is yellow in color.'
        },
        {   
            id: 2,
            question : "How many eyes do we have?",
            answer: "2/two",
            displayAnswer: 'We have two eyes.'
        },
        {   
            id: 3,
            question : "Which planet do we reside in?",
            answer: "earth",
            displayAnswer: 'We reside on the planet Earth.'
        },
        {   
            id: 4,
            question : "What is the first thing we do in the morning?",
            answer: "brushteeth",
            displayAnswer: 'We brush our teeth as the first thing in the morning!'
        }
    ]

}

export default data;
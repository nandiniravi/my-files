function sayHello(name){
    console.log("Hello " + name + "!");
}

sayHello('Nandini');
//console.log(window); --> throws error because window is a run time env provided by JS Engine only in browse
//Not for node env

//Node Module Sysytem

console.log();

setTimeout();
clearTimeout();

setInterval();
clearInterval();

//For JS in browser, methods like above 5 are global objects.. so they can be called by
//windows.setTimeout();
//windows.clearInterval();
//...and so on

var message = '';
windows.message; - in browser

//Now in Node we dont have a 'windows' object, we have only 'global' object.
// so we can access the above functions as

global.setTimeout();
global.setInterval();
... and so on

var message = '';
global.message(); --> this will not work becuase message is scoped only for app.js and not tog lobal object

In Node Module system, if we have a function:

var sayHello = function(){

}

window.sayHello(); --> 
if we have the function binding to the global object every time, then if we create another function in another module,
then it gets overridden...so its better to not have functions bound to global object

//Node follows modular system -> meaning all variables and functions ARE SCOPED to this file
//So we have to explicitly export the values from one module to other
//So in Node, all files are modules

//Node:
//1. Node is a JS runtime environment - runs on normal computer - backend and not on browser
//2. Node has a V8 JS engine. it has some additional features such as filesystem, OS, and other modules
//3. Node is single threaded - Asynchronous - Non blocking execution. Doesnt wait for the event to happen,
//   instead pushes the pending task in the Event Queue (assigns instructions to CPU) - which is continuously monitored.
//4. Node has high speed - can serve many users/unit time and can be used for I/O intensive apps.
//   To be avoided in case of CPU intensive tasks, which will lead to long wait time
//5. Every js file in node app - is modular - meaning variables and functions are scoped only to that file.
//6. It needs to be explicitly exported for other modules to use it. (module.exports.key = value)
//7. Every script in one file is wrapped with Module wrapper function which has 5 parameters:
//   --> exports
//    --> require
//    --> modules --> console.log(module)
//    --> __filename - name of the file
//    --> __dirname - name of the folder
//8. Node Core Modules:
//    --> os
//    --> fs - fs.methods() have 2 versions - synchronous and async (async takes a callback func, which needs to be executed once the event occurs)
//    --> path
//    --> events - A signal that something has occured. Event Emitter class - look at the uppercase start letters


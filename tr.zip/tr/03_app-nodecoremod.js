//Node Core Modules

//1. Path M0dule

const path = require('path');
const pathObj = path.parse(__filename);
//console.log(pathObj);

const filePath = path.join(__dirname, 'folderName', 'fileName.js');
//console.log(filePath);

//2. OS
const os = require('os');
var totalMemory = os.totalmem();
var freeMemory = os.freemem();
//console.log('Total Memory of OS: ' + totalMemory);
//console.log('Free Memory of OS: ' + freeMemory);
//console.log(`Total Memory of OS is ${totalMemory}`); //Template string - ES6 - backtic #{placeholder}

//3. File System - all fs.methods() have 2 versions - sync and async - async takes a callback fun as 2nd arg(err, result)
const fs = require('fs');
const files = fs.readdirSync('./');  //Synchronous
//console.log(files);

fs.readdir('./',function(error, result){
    //if(error) 
        //console.log(error)
    //else
        //console.log(result);
});

//4. Events - A signal that something has occured. Event Emitter class - look at the uppercase start letters
const EventEmitter = require('events'); //class
const emitter = new EventEmitter(); //creating an object of that class

//Register a listener - emitter.addEventListener() or emitter.on(event, callback function - which will get)
//executed on listening to event
emitter.on('messageLogged', function(arg){
    //console.log('Listener called');
    //console.log(arg);
})

//Raise an event - tells that an event has occured
//emitter.emit('messageLogged');
emitter.emit('messageLogged', {id: 1, url: 'https://'});

emitter.on('Msg received', (msg) => {
    //console.log(`Logging your msg: ${msg.msg}`);
});

emitter.emit('Msg received', {msg: 'Hello World!'});

//5. http module
const http = require('http');

const server = http.createServer((req, res) => {
    if(req.url === '/'){
        res.write('Hello World!');
        res.end();
    }

    if(req.url === 'api/courses/'){
        res.write(JSON.stringify([1,2,3]));
        res.end();
    }
        
});
server.listen(3000);

console.log('Listening on port 3000...');
console.log('before');
getUser(1, displayuserName);
    getRepos(user.gitHubUserName, displayRepos);
        getCommits(repo, displayCommits);
        //CALLBACK HELL
    })
});

//console.log(user); //will be undefined, because it is asynchronous ie line1, 3, 4 then 2sec, 2
console.log('after');

// function getUser(id){
//     setTimeout(() => {
//         console.log('Reading a user from database...');
//         return {id: id, gitHubUserName : 'Mosh'};
//     }, 2000);

//     return 1;
// }

//Using Callback:

function getUser(id, callback){
    setTimeout(() => {
        console.log('Reading a user from database...');
        callback ({id: id, gitHubUserName : 'Mosh'});
    }, 2000);
}

function getRepos(userName, callback){
    setTimeout(() => {
        console.log('Calling Githb api');
        callback(['repo1', 'repo2', 'repo3']);
    }, 2000);
}

function displayCommitts(committs){
    console.log(committs);
}

function displayRepos(repos){
    console.log('Repos: ', repos);
}

function displayuserName(userName){
    console.log(userName);
}
//Asynchronous code
//comes to line 1 -> executes
//comes to line 2 -> schedules the task to be performed
//comes to line 3 -> executes
// then after 2 seconds, the scheduled task is executed
//Asynchronous does not mean multithreaded, it means single threaded only
//Necessary to underdtand the networking

//3 ways tp handle aynchronous opertaion:
//1. Callbacks
//2. Promises
//3. Async/await

//CALLBACK HELL - one function nested in another, second function in first, third in second
//solution - replace anonymous callback function to named function

//Promise - every promise is a function (resolve, reject) => {
    // async function...
    // resolve(1);
    // reject(error);
}

//Async await - await statements should always be wrapped with async function

// async function name(){
//     try{
//         const user = await getUser(1);
//     }
//     catch{
//         console.log(error);
//     }
// }
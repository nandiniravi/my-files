console.log('Before');
// const p = getUser(1);
// p.then((user) => console.log(user));

getUser(1)
    .then(user => getRepos(user.userName))
    .then(repos => getCommits(repos[0]))
    .then(commits => console.log('Commits: ', commits))
    .catch(console.log('error'));

//Async and Await
async function showCommits(){
    try{
        const user = await getUser(1);
        const repos = await getRepos(userName);
        const commits = await getCommits(repos[0]);
        console.log(commits);
    }
    catch{
        console.log('error', error.msg);
    }
}

showCommits(); //returns a Promise but with a void value
//in async await - we use try -catch blocks
// getRepos(userName);
// getCommits(repo);
console.log('After');

function getUser(id){
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            console.log('Reading user from a database');
            resolve({id: id, userName: 'Mosh'});

        }, 2000);
    })
}

function getRepos(userName){
    return new Promise((resolve, reject) => {
        console.log('Getting repos...')
        resolve(['repo1', 'repo2','repo3']);

    });
}

function getCommits(repo){
    return new Promise((resolve, reject) => {
        console.log('Getting Commits...');
        resolve('100 commits');
    })
}
//JS - Promise api - to simulate during testing
Promise.resolve(1);
const p = Promise.resolve({id: 1});
p.then(result => console.log(result));

const p1 = new Promise((resolve) => {
    console.log('Async Op 1');
    resolve(1);
});

const p2 = new Promise(resolve => {
    console.log('Async Op 2');
    resolve(2);
});

Promise.all([p1,p2])
    .then(result => console.log(result));
const p = new Promise((resolve, reject) => {
    //Kick off async work - resolve and reject are functions
    setTimeout(() => {
        //resolve(1); //promise status from pending to resolved = executes p.then()
        reject(new Error('message'));  //promise status from pending to reject = executes p.catch()
    }, 2000)
    //resolve(1);
    //reject(new Error('message'));
})

p.then(result => {
    console.log('Result: ', result); //in this case, 1 is the value
}).catch(error => console.log('Error: ', error.message));















//JS - Promises - it holds the eventual status of the asynchronous function.
//It can have 3 status:
// 1 - Pending - usually this is the state at the beginning
// 2 - Fulfilled/resolved - once the asyc function fires off, and fulfills - it an have a return value
// 3 - Rejected - when the async function fails
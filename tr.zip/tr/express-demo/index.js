const express = require('express'); //returns a function
const app = express(); //calling the function

const logger = require('./logger');

app.use(express.json()); //to be able to parse and update the req.body
app.use(epress.urlencoded({extended: true})); //t
app.use(epress.static(public)) //t

// app.get();
// app.post();
// app.put();
// app.delete();
// app.use();

// app.use((req,res,next) => {
//     console.log('Logging...');
//     next();
// })

app.use(logger);

const courses = [
    {
        id: 1,
        name: 'Node JS'
    },
    {   
        id: 2,
        name: 'React JS'
    },
    {   
        id: 3,
        name: 'Vanilla JS'
    }
];
//1. Get
app.get('/', (req,res) => {
    res.send('Hello World!');
});

app.get('/api/courses', (req,res) => {
    res.send([1,2,3,4]);
});

app.get('/api/courses/:id', (req,res) => {
    let course = courses.find(c => c.id === parseInt(req.params.id));
    if (!course){
        res.status(404).send('This course was not found! :(');
    } //404
    res.send(course);
});

app.post('/api/courses', (req,res) => {
    if(!req.body.name || req.body.name.length < 3){
        res.status(400).send('Course name is required and should be of minimum 4 character of length!');
    } //400 is for bad request
    const course = {
        id: courses.length + 1,
        name: req.body.name 
    };
    courses.push(course);
    res.send(course);
});

// app.get('api/posts/:year/:month', (req,res) => {
//     res.send(req.params);
//     res.send(req.query); //anything after ? https://localhost:3000/api/courses/2019/5?sortBy=name
// });

app.put('/api/courses/:id', (req,res) => {
    //Look up for course
    //if not found - return 404 response
    let course = courses.find(c => c.id === parseInt(req.params.id));
    if (!course){
        res.status(404).send('This course was not found! :(');
    } //404

    //if found - validate -using Joi
    //if validation failed - return 400 response  - Bad request

    //if validation success - proeed with changes
});

app.delete('api/courses/:id', (req,res) => {
     //if not found - return 404 response
     let course = courses.find(c => c.id === parseInt(req.params.id));
     if (!course){
         return res.status(404).send('This course was not found! :(');
     } //404

     const index = courses.indexOf(course);
     courses.splice(index, 1);
     res.send(courses);
});

app.listen(3000, () => console.log('Listening on port 3000...'));

// const port = process.env.PORT || 3000;
// app.listen(port);
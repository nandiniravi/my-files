const log = (req,res,next) => {
    console.log('Logging...');
    next();
}

modules.export = log;
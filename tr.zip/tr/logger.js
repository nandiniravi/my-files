const EventEmitter = require('events'); //class
// const emitter = new EventEmitter();

var url= "http://mylogger.io/log";

class Logger extends EventEmitter{
    log(message){
    //send http req
    console.log(message);
    this.emit('messageLogged', message);
    }
}

//console.log('__Filename: ' + __filename);
//console.log('__dirname: ' + __dirname);

//module.exports.log = log;
//module.exports.url = url;
module.exports = Logger;

//every function is wrapped with Module wrapper function
//function(exports, require, module, __filename, __dirname)
// const http = require('http');
const path = require('path');

const express = require('express');
const bodyParser = require('body-parser');

const app = express();

app.use(bodyParser.urlencoded({extended: false}));

app.use('/add-product', (req,res,next) => {
    res.sendFile(path.join(__dirname, 'views', 'add-product.html'));
    // console.log('I am in middleware');
    // res.send('<form action="/product" method="POST"><input type="text" name="title"><button type="submit">Add Product</button></form>');
    //next(); //Allows the request to go to the next middleware in line - either give next() or return page
});

app.post('/product', (req,res,next) => {
    console.log(req.body);
    res.redirect('/');
})

app.use('/',(req,res,next) => {
    // console.log('I am in middleware 2');
    res.sendFile(path.join(__dirname, 'views', 'shop.html')); //updates res.setHeader('Content-Type','text-html');
});

app.use((req,res,next) => {
    res.status(404).sendFile(path.join(__dirname, 'views', 'page-not-found.html'));
})

//in express => the functions moves through a funnel 
// const server = http.createServer(app);

app.listen(3000);
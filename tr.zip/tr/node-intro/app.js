const http = require('http');
const routes = require('./routes');

const server = http.createServer(routes);

server.listen(3000);









//req.on('end',function) => Node registers the function which needs to be executed in future on some event happening.
//Node will not wait till it happens, it run asynchronously
//Sometimes, you need not 

    // console.log(req.url, req.method, req.headers);
    // process.exit();


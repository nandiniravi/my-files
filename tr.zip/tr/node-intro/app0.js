const http = require('http'); //this will look for node core module, if we need to import 
                              //our js file we need to use './filename' - relative path 
                              //and  '/filename' for absolute path
const fs = require('fs');
                                                    // js creates 2 objects for us - req, res(we give the names)
const server = http.createServer(function(req,res){  //this function executes whenever a request is received - event driven model
    //console.log(req.url, req.method, req.headers); //req is an object that is created when the request is received
    //process.exit();

    const url = req.url;
    const method = req.method;

    if(url === '/'){
        res.write('<html>');
        res.write('<head><title>Enter Message</title></head>');
        res.write('<body><form action="/message" method="POST"><input type="text" name="message"/><button type="submit">Send</button></form></body>');
        res.write('</html>');
        return res.end();
    }

    if(url === '/message' && method === 'POST'){
        const body = [];
        req.on('data', (chunk)=> {  //function to be executed on receiving every data piece
            console.log(chunk);
            body.push(chunk);
        });
        req.on('end',()=>{
            const parsedBody = Buffer.concat(body).toString();
            console.log(parsedBody);
            const message = parsedBody.split('=')[1];
            fs.writeFileSync('message.txt',message);
            res.statusCode = 302;
            res.setHeader('Location', '/');
            return res.end();
        });
        
        
    }
    res.setHeader('Content-type', 'text/html');
    res.write('<html>');
    res.write('<head><title>My HTML Response</title></head>');
    res.write('<body><h1>Hello World, I am from app.js</h1></body>');
    res.write('</html>');
    res.end();
});

server.listen(3000);
console.log('Hello World from Node.js');

//Creates a new file - first input is filename and second is the data in it
const fs = require('fs');
fs.writeFileSync('hello.txt', 'Hello World from Node.js');

//Client ---Request-----> Server| -->Database Connection
//   |                          |   Authentication
//   <--------------Response<----   Input Validation
//                                  Business Logic

//Node js is the javascript runtime environment - works outside the browser

//2 types of running the node program:
//1) REPL - Read, Evaluate, Print, Loop - Node cmd - Great Playground
//2) Execute files - Used for real apps, predicted sequence of steps

//array.map() always returns a new array
//Reference types => stores only the address of the reference data types - array, object etc.
//Immutability - dont edit the existing data, instead create a copy and edit that

//Spread operator -> const copy = [...myArray];
//                -> const copy = {...myObject};

//Rest operator -> function(arg1, arg2, arg3){return [arg1, arg2, arg3];};
// when you dont know the number of args, we use rest operaator
// function(...args){return args;} ==> Rest operator will automatically bundle the arguments to an array

//Destructuring const {name, age} = person (person should have properties name and age)
//Destructuring array const [hobby1, hobby 2] = hobbies; (hobbies = ['sports', 'cooking']);

setTimeout(()=> {
    console.log('Timer is done!'); //asynchronous code
}, 2000);

console.log('hello'); //Synchronous code
console.log('hi');

//Javascript does not wait for the async code to run the code below.. it runs the synchronous code

//Server is a program that accepts request and serves a response (usually a HTML file and the data is transferred as JSON or XML)
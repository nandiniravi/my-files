var _ = require('underscore');

//first it thinks its a node core module
//second it thinks its another js module in this project
//third it thinks its a module in node_modules

var result = _.contains([1,2,3],2);
console.log(result);
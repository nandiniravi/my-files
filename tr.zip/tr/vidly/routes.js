const express = require('express');
const router = express.Router();

const genres = [
    {id: 1, genre: 'Action'},
    {id: 2, genre: 'Thriller'},
    {id: 3, genre: 'Romance'},
    {id: 4, genre: 'Horror'}
];

// GET request
//sending all genres
router.get('/api/genres', (req,res) => {
    res.send(genres);
});

//sending one genre by id
router.get('/api/genres/:id', (req,res) => {
    let genreId = genres.find(each => each.id === parseInt(req.params.id));
    if (!genreId)
        res.status(404).send('The genre Id is not found!');
    res.send(genreId);
});

//POST request - adding a new genre to the list
router.post('/api/genres', (req,res) => {
    if(!req.body.genre || req.body.genre.length < 4)
        res.status(400).send('Enter a valid genre name and its minimum length should be 3.');
    const newGenre = {id: genres.length +1, genre: req.body.genre};
    genres.push(newGenre);
    res.send(newGenre);
});

//PUT request
router.put('/api/genres/:id', (req,res) => {
    let genreId = genres.find(each => each.id === parseInt(req.params.id));
    let index = genreId.id;
    if(!genreId)
        res.status(400).send('The genre with the given Id is not found!');
    if(!req.body.genre || req.body.genre.length <4)
        res.status(400).send('Enter a valid genre');
    genres[index-1].genre = req.body.genre;
    res.send(genres);
   
});

//DELETE request
router.delete('/api/genres/:id', (req,res) => {
    let chosenGenre = genres.find(each => each.id === parseInt(req.params.id));
    if(!chosenGenre)
        res.status(400).send('Enter a valid Id');
    let index = chosenGenre.id-1;
    genres.splice(index,1);
    res.send(genres);
});

module.exports = router;